"use client";

import { useEffect, useState } from "react";
import { formatMoscow, formatRub, normalizePhone } from "@/lib/dates";
import { ROOMS, type StatusMap } from "@/lib/rooms";

type Lead = {
  id: number;
  name: string;
  phone: string;
  datesLabel: string | null;
  nights: number | null;
  guests: string;
  roomLabel: string | null;
  comment: string | null;
  estimateRub: number | null;
  telegramStatus: string;
  telegramError: string | null;
  createdAt: string;
};

type Overview = {
  ok: true;
  telegramConfigured: boolean;
  botUsername?: string | null;
  stats: { total: number; sent: number; failed: number };
  rooms: StatusMap;
  bookings: Lead[];
};

const STORAGE_KEY = "topolki-admin-pass";

async function adminRequest(password: string, body: Record<string, unknown>) {
  const response = await fetch("/api/admin", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${password}`,
    },
    body: JSON.stringify(body),
  });
  const data = (await response.json().catch(() => null)) as { ok?: boolean; error?: string } | Overview | null;
  if (!response.ok || !data || data.ok === false) {
    throw new Error(data && "error" in data && data.error ? data.error : "Не удалось открыть панель");
  }
  return data;
}

export function AdminDashboard() {
  const [password, setPassword] = useState("");
  const [saved, setSaved] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(false);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [filter, setFilter] = useState<"all" | "failed" | "sent">("all");
  const [busyId, setBusyId] = useState<string | number | null>(null);

  async function load(nextPassword: string) {
    setLoading(true);
    setError("");
    try {
      const data = (await adminRequest(nextPassword, { action: "overview" })) as Overview;
      setSaved(nextPassword);
      sessionStorage.setItem(STORAGE_KEY, nextPassword);
      setOverview(data);
    } catch (reason) {
      setSaved("");
      sessionStorage.removeItem(STORAGE_KEY);
      setOverview(null);
      setError(reason instanceof Error ? reason.message : "Ошибка входа");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    if (stored) {
      setPassword(stored);
      void load(stored);
    }
  }, []);

  async function toggle(roomId: string) {
    setBusyId(roomId);
    setError("");
    try {
      await adminRequest(saved, { action: "toggle", roomId });
      await load(saved);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Не удалось сменить статус");
    } finally {
      setBusyId(null);
    }
  }

  async function ping() {
    setBusyId("ping");
    setError("");
    setNotice("");
    try {
      await adminRequest(saved, { action: "ping" });
      setNotice("Проверка ушла в Telegram. Если сообщения нет — нажмите «Запустить» в боте и повторите.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Telegram не принял проверку");
    } finally {
      setBusyId(null);
    }
  }

  async function resend(bookingId: number) {
    setBusyId(bookingId);
    setError("");
    try {
      await adminRequest(saved, { action: "resend", bookingId });
      await load(saved);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Telegram не принял повтор");
    } finally {
      setBusyId(null);
    }
  }

  function logout() {
    sessionStorage.removeItem(STORAGE_KEY);
    setSaved("");
    setOverview(null);
    setPassword("");
  }

  const leads = (overview?.bookings || []).filter((lead) => (filter === "all" ? true : lead.telegramStatus === filter));

  return (
    <main className="admin-page">
      <div className="wrap">
        <div className="admin-hero">
          <a className="logo" href="/">
            <span className="logo-mark" aria-hidden="true">Т</span>
            <span>
              <strong>Топольки · модератор</strong>
              <span>заявки и статусы номеров</span>
            </span>
          </a>
          {overview ? (
            <button className="btn ghost small" type="button" onClick={logout}>
              Выйти
            </button>
          ) : null}
        </div>

        {!overview ? (
          <form
            className="panel login-card"
            onSubmit={(event) => {
              event.preventDefault();
              void load(password.trim());
            }}
          >
            <h2>Вход для модератора</h2>
            <p className="modal-sub">Здесь видны готовые заявки и можно отметить номер занятым. Гости это сразу увидят на сайте.</p>
            <div className="field">
              <label htmlFor="adminPass">Пароль</label>
              <input id="adminPass" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} />
            </div>
            {error ? <p className="err show">{error}</p> : null}
            <button className="btn green" type="submit" disabled={loading} style={{ width: "100%" }}>
              {loading ? "Проверяем…" : "Войти"}
            </button>
          </form>
        ) : (
          <>
            <div className="admin-stats">
              <article className="stat">
                <b>{overview.stats.total}</b>
                <span>заявок всего</span>
              </article>
              <article className="stat">
                <b>{overview.stats.sent}</b>
                <span>ушли в Telegram</span>
              </article>
              <article className="stat">
                <b>{overview.stats.failed}</b>
                <span>не доставлены</span>
              </article>
              <article className="stat">
                <b>{overview.telegramConfigured ? "бот на связи" : "бот не задан"}</b>
                <span>отправка модератору</span>
              </article>
            </div>
            {notice ? <p className="summary">{notice}</p> : null}
            {error ? <p className="warn">{error}</p> : null}
            <section className="panel" style={{ marginBottom: 16 }}>
              <h2>Номера</h2>
              <div className="admin-rooms">
                {ROOMS.map((room) => {
                  const busy = overview.rooms[room.id] === "busy";
                  return (
                    <article key={room.id} className="admin-room">
                      <div>
                        <strong>{room.name}</strong>
                        <span>
                          {room.address} · от {formatRub(room.priceFrom)}
                        </span>
                      </div>
                      <b className={busy ? "pill bad" : "pill ok"}>{busy ? "Занят" : "Свободен"}</b>
                      <button className="btn ghost small" type="button" disabled={busyId === room.id} onClick={() => void toggle(room.id)}>
                        {busy ? "Освободить" : "Занять"}
                      </button>
                    </article>
                  );
                })}
              </div>
            </section>
            <section className="panel">
              <h2>Заявки</h2>
              <div className="filters">
                {(
                  [
                    ["all", "Все"],
                    ["sent", "В Telegram"],
                    ["failed", "Не ушли"],
                  ] as const
                ).map(([value, label]) => (
                  <button key={value} type="button" className={filter === value ? "filter-btn active" : "filter-btn"} onClick={() => setFilter(value)}>
                    {label}
                  </button>
                ))}
              </div>
              {leads.length === 0 ? <p className="sec-sub">Заявок в этом списке пока нет.</p> : null}
              <div className="lead-list">
                {leads.map((lead) => (
                  <article key={lead.id} className="lead-card">
                    <header>
                      <strong>
                        №{lead.id} · {lead.name}
                      </strong>
                      <b className={lead.telegramStatus === "sent" ? "pill ok" : lead.telegramStatus === "failed" ? "pill bad" : "pill wait"}>
                        {lead.telegramStatus === "sent" ? "В Telegram" : lead.telegramStatus === "failed" ? "Не доставлено" : "Ждёт"}
                      </b>
                    </header>
                    <time>{formatMoscow(new Date(lead.createdAt))}</time>
                    <p>{lead.phone}</p>
                    <p>
                      {lead.datesLabel || "даты не указаны"} · {lead.guests} гост.
                      {lead.estimateRub ? ` · ориентир ${formatRub(lead.estimateRub)}` : ""}
                    </p>
                    <p>{lead.roomLabel || "номер не выбран"}</p>
                    {lead.comment ? <p>Комментарий: {lead.comment}</p> : null}
                    {lead.telegramError ? <p>Ошибка: {lead.telegramError}</p> : null}
                    <div className="lead-actions">
                      <a className="btn wa small" href={`https://wa.me/${normalizePhone(lead.phone) || lead.phone.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer">
                        WhatsApp
                      </a>
                      <a className="btn ghost small" href={`tel:${lead.phone}`}>
                        Позвонить
                      </a>
                      <button className="btn tg small" type="button" disabled={busyId === lead.id} onClick={() => void resend(lead.id)}>
                        {lead.telegramStatus === "sent" ? "Отправить ещё раз" : "Повторить в Telegram"}
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          </>
        )}
      </div>
    </main>
  );
}
