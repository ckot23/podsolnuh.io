"use client";

import { useEffect, useState } from "react";
import { BookingModal } from "@/components/booking-modal";
import { Icon } from "@/components/icon";
import { formatRub } from "@/lib/dates";
import {
  PHONE_PRIMARY,
  PHONE_PRIMARY_LABEL,
  PHONE_SECONDARY,
  PHONE_SECONDARY_LABEL,
  ROOMS,
  TELEGRAM_HANDLE,
  TELEGRAM_URL,
  WHATSAPP_URL,
  type StatusMap,
} from "@/lib/rooms";

const NEARBY = [
  { title: "Краевой призывной пункт («Девятка»)", text: "Краевой пункт отбора на военную службу.", dist: "80 м", icon: "shield" as const },
  { title: "Университет МВД", text: "Краснодарский университет МВД России.", dist: "рядом", icon: "cap" as const },
  { title: "Лётное училище", text: "Краснодарское высшее военное авиационное училище лётчиков.", dist: "рядом", icon: "plane" as const },
  { title: "Училище им. Штеменко", text: "Краснодарское высшее военное училище (шифровальное).", dist: "рядом", icon: "lock" as const },
  { title: "«Красная площадь»", text: "Первый мегацентр на Кубани: магазины, кино, еда.", dist: "800 м", icon: "bag" as const },
  { title: "«Экспоград-Юг»", text: "Главный выставочный центр Кубани.", dist: "15 мин", icon: "home" as const },
];

const FAQ = [
  ["Есть ли комиссии и доплаты?", "Нет. Вы бронируете напрямую у собственника — без комиссий и дополнительных платежей."],
  ["Что уже есть в номере?", "Кухонная зона с бытовой техникой и посудой, полноразмерный холодильник, спальные места, душ и туалет. Останется только купить продукты."],
  ["Где припарковать машину?", "На придомовой территории — тихий непроходной двор с видеонаблюдением."],
  ["От чего зависит цена?", "От даты, срока проживания и количества человек. В заявке мы показываем ориентир «от», точную стоимость подтверждаем в ответ."],
  ["Как забронировать?", `Оставьте заявку на сайте — она сразу придёт собственнику в Telegram. Или позвоните ${PHONE_PRIMARY_LABEL}, напишите в WhatsApp и Telegram ${TELEGRAM_HANDLE}.`],
];

export function Site({ initialStatuses }: { initialStatuses: StatusMap }) {
  const [statuses, setStatuses] = useState(initialStatuses);
  const [bookOpen, setBookOpen] = useState(false);
  const [bookRoom, setBookRoom] = useState("");
  const [policyOpen, setPolicyOpen] = useState(false);
  const year = new Date().getFullYear();

  useEffect(() => {
    const header = document.getElementById("header");
    if (!header) return;
    const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    let stop = false;
    async function refresh() {
      try {
        const response = await fetch("/api/rooms", { cache: "no-store" });
        const data = (await response.json()) as { ok?: boolean; rooms?: StatusMap };
        if (!stop && data.ok && data.rooms) setStatuses(data.rooms);
      } catch {
        /* сайт работает и без свежих статусов */
      }
    }
    const timer = window.setInterval(refresh, 20000);
    return () => {
      stop = true;
      window.clearInterval(timer);
    };
  }, []);

  function openBook(roomId = "") {
    if (roomId && statuses[roomId] === "busy") return;
    setBookRoom(roomId);
    setBookOpen(true);
  }

  return (
    <>
      <a className="skip-link" href="#main">Перейти к содержимому</a>
      <header id="header">
        <div className="wrap top">
          <a className="logo" href="#top" aria-label="На главную">
            <span className="logo-mark" aria-hidden="true">Т</span>
            <span>
              <strong>Топольки · посуточно</strong>
              <span>Краснодар, от собственника</span>
            </span>
          </a>
          <nav aria-label="Основная навигация">
            <ul>
              <li><a href="#rooms">Номера</a></li>
              <li><a href="#benefits">Почему мы</a></li>
              <li><a href="#near">Рядом</a></li>
              <li><a href="#faq">Вопросы</a></li>
              <li><a href="#contacts">Контакты</a></li>
            </ul>
          </nav>
          <div className="top-contacts">
            <a className="top-phone" href={`tel:${PHONE_PRIMARY}`}>
              {PHONE_PRIMARY_LABEL}
              <small>бронирование</small>
            </a>
            <a className="btn tg small" href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">
              Telegram
            </a>
            <button className="btn primary small" type="button" onClick={() => openBook()}>
              Забронировать
            </button>
          </div>
        </div>
      </header>

      <main id="main">
        <div className="wrap" id="top">
          <section className="hero" aria-labelledby="hero-title">
            <div>
              <p className="kicker">Напрямую от собственника · без комиссий</p>
              <h1 id="hero-title">Квартиры и номера посуточно в Краснодаре</h1>
              <p className="lead">
                Студии с собственной кухней — современная альтернатива гостинице, только дешевле и удобнее. Одно-, двух-, трёхместное и семейное размещение. <b>Всё необходимое уже в номере.</b>
              </p>
              <ul className="hero-points">
                {[
                  "Без комиссий и дополнительных платежей",
                  "Кухонная зона: техника, посуда, полноразмерный холодильник",
                  "Парковка во дворе и видеонаблюдение",
                  "80 м до краевого призывного пункта, 800 м до «Красной площади»",
                ].map((point) => (
                  <li key={point}>
                    <Icon name="check" size={18} />
                    {point}
                  </li>
                ))}
              </ul>
              <div className="cta-row">
                <button className="btn primary" type="button" onClick={() => openBook()}>Забронировать</button>
                <a className="btn tg" href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">Telegram {TELEGRAM_HANDLE}</a>
                <a className="btn ghost" href={`tel:${PHONE_PRIMARY}`}>Позвонить</a>
              </div>
            </div>
            <div className="hero-visual">
              <img className="hero-photo" src="/images/hero.jpg" alt="Светлая студия с кухонной зоной и двуспальной кроватью" width={1456} height={816} />
              <div className="badge-float badge-price">от 2 000 ₽ <small>за сутки</small></div>
              <div className="badge-float badge-dist">Призывной пункт · 80 м</div>
            </div>
          </section>

          <ul className="stats" aria-label="Главное о размещении">
            <li className="stat reveal"><b>от 2 000 ₽</b><span>сутки проживания</span></li>
            <li className="stat reveal"><b>до 4 гостей</b><span>в одном номере</span></li>
            <li className="stat reveal"><b>2 корпуса</b><span>Цветочная 162 и Железнодорожная 180</span></li>
            <li className="stat reveal"><b>0 ₽</b><span>комиссий и переплат</span></li>
          </ul>

          <section id="rooms" aria-labelledby="rooms-title">
            <div className="sec-head">
              <p className="sec-kicker">Номера и цены</p>
              <h2 id="rooms-title">Выберите свой вариант</h2>
              <p className="sec-sub">В каждом номере — кухонная зона с бытовой техникой и посудой, душ и туалет. Цена зависит от дат, срока и количества гостей.</p>
            </div>
            <div className="rooms">
              {ROOMS.map((room) => {
                const busy = statuses[room.id] === "busy";
                return (
                  <article key={room.id} className={busy ? "room room-busy" : "room"}>
                    <div className="room-photo">
                      <img src={room.image} alt={room.alt} width={1456} height={816} />
                      <span className="room-addr">{room.address}</span>
                      <span className={busy ? "status-chip busy" : "status-chip free"}>{busy ? "Занят" : "Свободен"}</span>
                      <span className="room-price">от {formatRub(room.priceFrom)} <small>/ сутки</small></span>
                    </div>
                    <div className="room-body">
                      <h3>{room.name}</h3>
                      <span className="room-guests"><Icon name="users" size={16} />{room.guestsLabel}</span>
                      <p className="room-desc">{room.description}</p>
                      <ul className="chips">{room.amenities.map((item) => <li key={item}>{item}</li>)}</ul>
                      <div className="room-cta">
                        <button className="btn primary" type="button" disabled={busy} onClick={() => openBook(room.id)}>
                          {busy ? "Сейчас занят" : "Забронировать"}
                        </button>
                        <a className="btn ghost" href={`tel:${PHONE_PRIMARY}`}>Уточнить цену</a>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
            <p className="rooms-note">
              Цена зависит от даты, срока проживания и количества человек — уточняйте по телефону <a href={`tel:${PHONE_SECONDARY}`}>{PHONE_SECONDARY_LABEL}</a>. Скажете даты — сразу назовём точную стоимость.
            </p>
          </section>

          <section id="benefits" aria-labelledby="benefits-title">
            <div className="sec-head">
              <p className="sec-kicker">Почему у нас</p>
              <h2 id="benefits-title">Жить как дома, платить как за номер</h2>
              <p className="sec-sub">Студия — это аналог гостиничного номера с главным преимуществом: собственной кухней.</p>
            </div>
            <div className="benefits">
              <div className="benefit">
                <div className="benefit-icon"><Icon name="card" /></div>
                <div><h3>Напрямую от собственника</h3><p>Без комиссий, посредников и дополнительных платежей. Цена, которую назвали при брони, — финальная.</p></div>
              </div>
              <div className="benefit">
                <div className="benefit-icon"><Icon name="kitchen" /></div>
                <div><h3>Полноценная кухня</h3><p>Не зависите от меню кафе и фудкортов: готовьте любимые блюда. Посуда и электроприборы есть, холодильник вместит все продукты.</p></div>
              </div>
              <div className="benefit">
                <div className="benefit-icon"><Icon name="car" /></div>
                <div><h3>Парковка во дворе</h3><p>Придомовая территория: всегда есть место для машины. Тихое непроходное расположение и видеонаблюдение — дополнительный плюс для сохранности авто.</p></div>
              </div>
              <div className="benefit">
                <div className="benefit-icon"><Icon name="users" /></div>
                <div><h3>Разное размещение</h3><p>Одно-, двух-, трёхместное и семейное. Подберём номер под вашу компанию и даты.</p></div>
              </div>
              <div className="benefit benefit-wide">
                <img src="/images/yard-parking.jpg" alt="Тихий двор с парковочными местами и видеонаблюдением" width={1456} height={816} />
                <div className="bw-text">
                  <h3>Тихий двор, спокойно за машину</h3>
                  <p>Непроходное месторасположение: во дворе тихо, а видеонаблюдение присматривает за парковкой. Вы отдыхаете — машина под присмотром.</p>
                </div>
              </div>
            </div>
          </section>

          <section id="near" aria-labelledby="near-title">
            <div className="sec-head">
              <p className="sec-kicker">Расположение</p>
              <h2 id="near-title">Рядом с нами</h2>
              <p className="sec-sub">Нас выбирают призывники, абитуриенты, командировочные и гости выставок — всё ключевое совсем рядом.</p>
            </div>
            <div className="near">
              {NEARBY.map((place) => (
                <div className="near-card" key={place.title}>
                  <div className="near-icon"><Icon name={place.icon} /></div>
                  <div className="near-copy"><h3>{place.title}</h3><p>{place.text}</p></div>
                  <span className="near-dist">{place.dist}</span>
                </div>
              ))}
            </div>
          </section>

          <section id="steps" aria-labelledby="steps-title">
            <div className="sec-head">
              <p className="sec-kicker">Бронирование</p>
              <h2 id="steps-title">Три шага до заселения</h2>
            </div>
            <div className="steps">
              <div className="step"><h3>Заявка</h3><p>Оставьте заявку на сайте — готовое сообщение сразу придёт собственнику в Telegram. Можно также позвонить, написать в WhatsApp или {TELEGRAM_HANDLE}.</p></div>
              <div className="step"><h3>Подтверждение</h3><p>Согласуем даты, точную цену и номер. Без предоплат-сюрпризов: условия фиксируем сразу.</p></div>
              <div className="step"><h3>Заселение</h3><p>Приезжайте и живите как дома: кухня, посуда и всё необходимое уже ждут вас.</p></div>
            </div>
          </section>

          <section id="faq" aria-labelledby="faq-title">
            <div className="sec-head">
              <p className="sec-kicker">Вопросы и ответы</p>
              <h2 id="faq-title">Перед бронированием</h2>
            </div>
            {FAQ.map(([question, answer]) => (
              <details className="faq-item" key={question}>
                <summary>{question}</summary>
                <p>{answer}</p>
              </details>
            ))}
          </section>

          <section id="contacts" aria-labelledby="contacts-title">
            <div className="sec-head">
              <p className="sec-kicker">Контакты</p>
              <h2 id="contacts-title">Два корпуса в Топольках</h2>
            </div>
            <div className="contacts-grid">
              <div className="addr-card">
                <h3><Icon name="pin" size={18} />Корпус №1</h3>
                <p>Краснодар, СТ4 Топольки,<br />ул. Цветочная, 162</p>
                <div className="mess-row"><a className="btn ghost" href={`tel:${PHONE_PRIMARY}`}>{PHONE_PRIMARY_LABEL}</a></div>
              </div>
              <div className="addr-card">
                <h3><Icon name="pin" size={18} />Корпус №2</h3>
                <p>Краснодар, СТ4 Топольки,<br />ул. Железнодорожная, 180</p>
                <div className="mess-row"><a className="btn ghost" href={`tel:${PHONE_SECONDARY}`}>{PHONE_SECONDARY_LABEL}</a></div>
              </div>
              <div className="addr-card" style={{ gridColumn: "1 / -1" }}>
                <h3>Мессенджеры</h3>
                <p>Пишите {TELEGRAM_HANDLE} — ответим, пришлём свободные даты и точную цену. Заявка с сайта тоже приходит в Telegram.</p>
                <div className="mess-row">
                  <a className="btn tg" href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">Telegram {TELEGRAM_HANDLE}</a>
                  <a className="btn wa" href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">WhatsApp</a>
                  <button className="btn green" type="button" onClick={() => openBook()}>Оставить заявку</button>
                </div>
              </div>
              <div className="map-wrap">
                <iframe className="map-frame" title="Карта: корпуса на Цветочной 162 и Железнодорожной 180" src="https://yandex.ru/map-widget/v1/?um=constructor%3A741d186b29439d0754681dd2700d105a2240e59e27826ee07a9cd34b11112d03&source=constructor" loading="lazy" />
              </div>
            </div>
          </section>
        </div>
      </main>

      <footer>
        <div className="wrap foot">
          <div>
            <strong>Топольки · посуточно</strong>
            <p>Квартиры и номера посуточно в Краснодаре — напрямую от собственника.</p>
            <p className="foot-note">© {year} · Без комиссий и дополнительных платежей</p>
          </div>
          <div>
            <strong>Адреса</strong>
            <p>Цветочная, 162</p>
            <p>Железнодорожная, 180</p>
          </div>
          <div>
            <strong>Связь</strong>
            <p><a href={`tel:${PHONE_PRIMARY}`}>{PHONE_PRIMARY_LABEL}</a></p>
            <p><a href={`tel:${PHONE_SECONDARY}`}>{PHONE_SECONDARY_LABEL}</a></p>
            <p>
              <a href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">Telegram {TELEGRAM_HANDLE}</a>
              {" · "}
              <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">WhatsApp</a>
            </p>
            <p><button type="button" onClick={() => setPolicyOpen(true)} style={{ background: "none", border: 0, padding: 0, color: "#f0c9a8", fontWeight: 600 }}>Политика конфиденциальности</button></p>
            <p className="foot-note"><a href="/admin">Для модератора</a></p>
          </div>
        </div>
      </footer>

      <div className="sticky-cta">
        <a className="btn ghost" href={`tel:${PHONE_PRIMARY}`}>Звонок</a>
        <a className="btn tg" href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">Telegram</a>
        <button className="btn primary" type="button" onClick={() => openBook()}>Бронь</button>
      </div>

      <BookingModal
        open={bookOpen}
        initialRoomId={bookRoom}
        statuses={statuses}
        onClose={() => setBookOpen(false)}
        onOpenPolicy={() => setPolicyOpen(true)}
      />

      {policyOpen ? (
        <div className="modal-backdrop policy-modal" role="dialog" aria-modal="true" aria-labelledby="policyTitle" onClick={() => setPolicyOpen(false)}>
          <div className="modal" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" type="button" aria-label="Закрыть" onClick={() => setPolicyOpen(false)}>×</button>
            <h3 id="policyTitle">Политика конфиденциальности</h3>
            <p>Политика действует в отношении данных, которые пользователь указывает на сайте посуточной аренды «Топольки» в Краснодаре. Отправка заявки означает согласие с Политикой.</p>
            <p><b>1. Состав данных.</b> Имя, телефон, даты проживания, число гостей, выбранный номер и комментарий. Технические данные вроде IP используются только для защиты формы от спама.</p>
            <p><b>2. Цели.</b> Связаться с гостем, подтвердить бронь и цену. Заявка передаётся собственнику в Telegram и сохраняется, чтобы её не потерять.</p>
            <p><b>3. Кому передаём.</b> Только собственнику жилья и модератору заявок. Данные не продаются и не публикуются.</p>
            <p><b>4. Срок.</b> Заявки хранятся, пока нужны для заселения и ответов гостям, затем удаляются.</p>
            <p><b>5. Права.</b> Можно попросить уточнить или удалить заявку по телефону {PHONE_PRIMARY_LABEL}.</p>
          </div>
        </div>
      ) : null}
    </>
  );
}
