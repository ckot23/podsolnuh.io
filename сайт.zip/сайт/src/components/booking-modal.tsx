"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  MONTHS,
  addMonthsISO,
  datesLabel,
  formatRub,
  monthMatrix,
  moscowTodayISO,
  nightsBetween,
  normalizePhone,
} from "@/lib/dates";
import {
  GUEST_OPTIONS,
  PHONE_PRIMARY_LABEL,
  ROOMS,
  TELEGRAM_HANDLE,
  TELEGRAM_URL,
  WHATSAPP_NUMBER,
  getRoom,
  isOverCapacity,
  type StatusMap,
} from "@/lib/rooms";
import { Icon } from "./icon";

type Props = {
  open: boolean;
  initialRoomId: string;
  statuses: StatusMap;
  onClose: () => void;
  onOpenPolicy: () => void;
};

type Field = "name" | "phone" | "dates" | "room" | "consent";

const EMPTY_ERRORS: Record<Field, string> = {
  name: "",
  phone: "",
  dates: "",
  room: "",
  consent: "",
};

export function BookingModal({ open, initialRoomId, statuses, onClose, onOpenPolicy }: Props) {
  const today = moscowTodayISO();
  const [year, month] = today.split("-").map(Number);
  const [view, setView] = useState({ y: year, m: month - 1 });
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [guests, setGuests] = useState("2");
  const [roomId, setRoomId] = useState(initialRoomId);
  const [comment, setComment] = useState("");
  const [consent, setConsent] = useState(true);
  const [website, setWebsite] = useState("");
  const [errors, setErrors] = useState(EMPTY_ERRORS);
  const [status, setStatus] = useState<{ text: string; state: "" | "ok" | "error" }>({ text: "", state: "" });
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<{ id?: number; telegram: boolean; warning?: string; text: string } | null>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    setRoomId(initialRoomId);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onCloseRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, initialRoomId]);

  const room = getRoom(roomId);
  const nights = checkIn && checkOut ? nightsBetween(checkIn, checkOut) : 0;
  const estimate = room && nights > 0 ? room.priceFrom * nights : null;
  const label = checkIn && checkOut && nights > 0 ? datesLabel(checkIn, checkOut) : "";
  const over = isOverCapacity(roomId, guests);
  const cells = useMemo(() => monthMatrix(view.y, view.m), [view]);
  const maxDate = addMonthsISO(today, 18);

  if (!open) return null;

  function reset() {
    setName("");
    setPhone("");
    setGuests("2");
    setRoomId("");
    setComment("");
    setCheckIn("");
    setCheckOut("");
    setConsent(true);
    setWebsite("");
    setErrors(EMPTY_ERRORS);
    setStatus({ text: "", state: "" });
    setDone(null);
  }

  function close() {
    if (done) reset();
    onClose();
  }

  function pickDay(day: string) {
    if (!checkIn || (checkIn && checkOut)) {
      setCheckIn(day);
      setCheckOut("");
      return;
    }
    if (day === checkIn) {
      setCheckIn("");
      return;
    }
    if (day < checkIn) {
      setCheckIn(day);
      return;
    }
    setCheckOut(day);
    setErrors((current) => ({ ...current, dates: "" }));
  }

  function shiftMonth(delta: number) {
    const next = new Date(view.y, view.m + delta, 1);
    const current = new Date(year, month - 1, 1);
    if (next < current) return;
    setView({ y: next.getFullYear(), m: next.getMonth() });
  }

  function validate() {
    const next = { ...EMPTY_ERRORS };
    if (name.trim().length < 2) next.name = "Представьтесь, пожалуйста.";
    if (!normalizePhone(phone)) next.phone = "Нужен телефон, чтобы перезвонить.";
    if (!checkIn || !checkOut || nights < 1) next.dates = "Выберите даты заезда и выезда.";
    if (roomId && statuses[roomId] === "busy") next.room = "Этот номер сейчас занят.";
    if (!consent) next.consent = "Нужно согласие на обработку данных.";
    setErrors(next);
    return !Object.values(next).some(Boolean);
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setStatus({ text: "", state: "" });
    if (!validate()) return;

    const payload = {
      name: name.trim(),
      phone: phone.trim(),
      checkIn,
      checkOut,
      guests,
      roomId,
      comment: comment.trim(),
      consent: true,
      website,
    };
    const text = [
      "Здравствуйте! Хочу забронировать номер.",
      `Имя: ${payload.name}`,
      `Телефон: ${payload.phone}`,
      `Даты: ${label}`,
      `Гостей: ${guests}`,
      room ? `Номер: ${room.shortLabel}` : "Номер: подберите, пожалуйста",
      payload.comment ? `Комментарий: ${payload.comment}` : "",
    ]
      .filter(Boolean)
      .join("\n");

    setSubmitting(true);
    setStatus({ text: "Отправляем заявку собственнику…", state: "" });
    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json().catch(() => null)) as
        | { ok: true; id?: number; telegram?: boolean; warning?: string }
        | { ok: false; error?: string; field?: Field }
        | null;

      if (!response.ok || !data || !data.ok) {
        const message = data && "error" in data && data.error ? data.error : "Не удалось отправить заявку.";
        if (data && "field" in data && data.field && data.field in EMPTY_ERRORS) {
          setErrors((current) => ({ ...current, [data.field as Field]: message }));
        }
        setStatus({ text: message, state: "error" });
        return;
      }

      setDone({ id: data.id, telegram: Boolean(data.telegram), warning: data.warning, text });
      setStatus({ text: "", state: "" });
    } catch {
      setStatus({
        text: "Сеть недоступна. Заявка не подтверждена — напишите в Telegram или WhatsApp.",
        state: "error",
      });
    } finally {
      setSubmitting(false);
    }
  }

  const waHref = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(done?.text || "")}`;
  const atCurrentMonth = view.y === year && view.m === month - 1;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="bookTitle" onClick={close}>
      <div className="modal" onClick={(event) => event.stopPropagation()}>
        <button className="modal-close" type="button" aria-label="Закрыть" onClick={close}>
          ×
        </button>
        {done ? (
          <div className="success-panel">
            <div className="success-mark">
              <Icon name="check" size={30} />
            </div>
            <h3 id="bookTitle">{done.telegram ? "Заявка отправлена" : "Заявка сохранена"}</h3>
            <p>
              {done.id ? `Номер заявки ${done.id}. ` : ""}
              {done.telegram
                ? "Готовая заявка уже у собственника в Telegram. Перезвоним и подтвердим точную цену."
                : done.warning || "В Telegram сейчас не доставилось. Напишите напрямую — текст заявки уже готов."}
            </p>
            <div className="success-actions">
              <a className="btn tg" href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">
                Telegram {TELEGRAM_HANDLE}
              </a>
              <a className="btn wa" href={waHref} target="_blank" rel="noopener noreferrer">
                WhatsApp
              </a>
              <button className="btn ghost" type="button" onClick={close}>
                Закрыть
              </button>
            </div>
          </div>
        ) : (
          <>
            <h3 id="bookTitle">Заявка на бронь</h3>
            <p className="modal-sub">
              Готовая заявка сразу уйдёт собственнику в Telegram. Перезвоним, подтвердим даты и назовём точную цену.
            </p>
            <form onSubmit={onSubmit} noValidate>
              <div className="vh" aria-hidden="true">
                <label htmlFor="website">Не заполняйте</label>
                <input id="website" value={website} onChange={(event) => setWebsite(event.target.value)} tabIndex={-1} autoComplete="off" />
              </div>
              <div className="field">
                <label htmlFor="fName">Ваше имя</label>
                <input id="fName" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" placeholder="Как к вам обращаться" />
                <p className={errors.name ? "err show" : "err"}>{errors.name}</p>
              </div>
              <div className="field">
                <label htmlFor="fPhone">Телефон</label>
                <input id="fPhone" value={phone} onChange={(event) => setPhone(event.target.value)} type="tel" inputMode="tel" autoComplete="tel" placeholder="+7 918 000-00-00" />
                <p className={errors.phone ? "err show" : "err"}>{errors.phone}</p>
              </div>
              <div className="field">
                <label id="calLabelText">Даты заезда и выезда</label>
                <div className="cal" role="group" aria-labelledby="calLabelText">
                  <div className="cal-head">
                    <button className="cal-nav" type="button" aria-label="Предыдущий месяц" onClick={() => shiftMonth(-1)} disabled={atCurrentMonth}>
                      ←
                    </button>
                    <b>
                      {MONTHS[view.m]} {view.y}
                    </b>
                    <button className="cal-nav" type="button" aria-label="Следующий месяц" onClick={() => shiftMonth(1)}>
                      →
                    </button>
                  </div>
                  <div className="cal-week" aria-hidden="true">
                    {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((day) => (
                      <span key={day}>{day}</span>
                    ))}
                  </div>
                  <div className="cal-grid">
                    {cells.map((day, index) => {
                      if (!day) return <span key={`empty-${index}`} className="cal-day empty" />;
                      const disabled = day < today || day > maxDate;
                      const classes = ["cal-day"];
                      if (day === today) classes.push("today");
                      if (day === checkIn) classes.push("range-start", checkOut ? "has-end" : "");
                      if (day === checkOut) classes.push("range-end");
                      if (checkIn && checkOut && day > checkIn && day < checkOut) classes.push("in-range");
                      return (
                        <button key={day} type="button" className={classes.filter(Boolean).join(" ")} disabled={disabled} onClick={() => pickDay(day)}>
                          {Number(day.slice(-2))}
                        </button>
                      );
                    })}
                  </div>
                </div>
                <p className="hint">{label || (checkIn ? "Теперь выберите дату выезда" : "Выберите дату заезда")}</p>
                <p className={errors.dates ? "err show" : "err"}>{errors.dates}</p>
              </div>
              <div className="field-row">
                <div className="field">
                  <label htmlFor="fGuests">Гостей</label>
                  <select id="fGuests" value={guests} onChange={(event) => setGuests(event.target.value)}>
                    {GUEST_OPTIONS.map((option) => (
                      <option key={option}>{option}</option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label htmlFor="fRoom">Номер</label>
                  <select id="fRoom" value={roomId} onChange={(event) => setRoomId(event.target.value)}>
                    <option value="">Подберите по телефону</option>
                    {ROOMS.map((item) => (
                      <option key={item.id} value={item.id} disabled={statuses[item.id] === "busy"}>
                        {item.shortLabel} · от {formatRub(item.priceFrom)}
                        {statuses[item.id] === "busy" ? " — занят" : ""}
                      </option>
                    ))}
                  </select>
                  <p className={errors.room ? "err show" : "err"}>{errors.room}</p>
                </div>
              </div>
              <div className="field">
                <label htmlFor="fComment">Комментарий</label>
                <textarea
                  id="fComment"
                  value={comment}
                  maxLength={500}
                  onChange={(event) => setComment(event.target.value)}
                  placeholder="Время заезда, с детьми или без — по желанию"
                />
              </div>
              {over ? (
                <p className="warn">Гостей больше, чем мест в выбранном номере. Заявку отправим — собственник предложит другой вариант.</p>
              ) : null}
              <div className="summary">
                <b>Как уйдёт заявка</b>
                <p>
                  {name.trim() || "Имя"} · {phone.trim() || "телефон"}
                  <br />
                  {label || "даты не выбраны"} · {guests} гост.
                  <br />
                  {room ? room.shortLabel : "номер подберём"}
                  {estimate ? ` · ориентир от ${formatRub(estimate)}` : ""}
                </p>
              </div>
              <label className="consent">
                <input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} />
                <span>
                  Согласие на обработку персональных данных.{" "}
                  <button type="button" onClick={onOpenPolicy} style={{ background: "none", border: 0, padding: 0, color: "var(--accent-dark)", fontWeight: 700 }}>
                    Политика
                  </button>
                </span>
              </label>
              <p className={errors.consent ? "err show" : "err"}>{errors.consent}</p>
              <button className="btn primary" type="submit" disabled={submitting} style={{ width: "100%" }}>
                {submitting ? "Отправляем…" : "Отправить заявку"}
              </button>
              <p className="form-status" data-state={status.state} role="status">
                {status.text}
              </p>
            </form>
            <p className="modal-alt">
              Или сразу: <a href="tel:+79181164554"><b>{PHONE_PRIMARY_LABEL}</b></a> ·{" "}
              <a href={TELEGRAM_URL} target="_blank" rel="noopener noreferrer">Telegram {TELEGRAM_HANDLE}</a> ·{" "}
              <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>
            </p>
          </>
        )}
      </div>
    </div>
  );
}
