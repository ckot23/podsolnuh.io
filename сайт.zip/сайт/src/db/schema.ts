import { integer, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  checkIn: varchar("check_in", { length: 20 }),
  checkOut: varchar("check_out", { length: 20 }),
  datesLabel: varchar("dates_label", { length: 120 }),
  nights: integer("nights"),
  guests: varchar("guests", { length: 10 }).notNull(),
  roomId: varchar("room_id", { length: 40 }),
  roomLabel: text("room_label"),
  comment: text("comment"),
  estimateRub: integer("estimate_rub"),
  telegramMessageId: varchar("telegram_message_id", { length: 40 }),
  telegramStatus: varchar("telegram_status", { length: 24 }).notNull().default("pending"),
  telegramError: text("telegram_error"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const roomStatuses = pgTable("room_statuses", {
  roomId: varchar("room_id", { length: 40 }).primaryKey(),
  status: varchar("status", { length: 20 }).notNull().default("free"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type BookingRecord = typeof bookings.$inferSelect;
export type RoomStatusRecord = typeof roomStatuses.$inferSelect;
