import { getStatusMap } from "@/lib/booking";
import { emptyStatusMap } from "@/lib/rooms";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rooms = await getStatusMap();
    return Response.json({ ok: true, rooms });
  } catch {
    return Response.json({ ok: true, rooms: emptyStatusMap() });
  }
}
