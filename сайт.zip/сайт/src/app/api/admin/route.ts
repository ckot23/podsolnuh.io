import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, roomStatuses } from "@/db/schema";
import { isAdminRequest, sameOrigin } from "@/lib/auth";
import { deliverBooking, getStatusMap } from "@/lib/booking";
import { getRoom } from "@/lib/rooms";
import { friendlyTelegramError, getBotUsername, sendModeratorPing } from "@/lib/telegram";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return Response.json({ ok: false, error: "Запрос отклонён." }, { status: 403 });
  }
  if (!isAdminRequest(request)) {
    return Response.json({ ok: false, error: "Неверный пароль." }, { status: 401 });
  }

  const body = (await request.json().catch(() => null)) as
    | { action?: string; roomId?: string; bookingId?: number }
    | null;
  const action = body?.action;

  try {
    if (action === "overview") {
      const rooms = await getStatusMap();
      const list = await db.select().from(bookings).orderBy(desc(bookings.createdAt)).limit(80);
      const [totals] = await db
        .select({
          total: sql<number>`count(*)::int`,
          sent: sql<number>`count(*) filter (where ${bookings.telegramStatus} = 'sent')::int`,
          failed: sql<number>`count(*) filter (where ${bookings.telegramStatus} = 'failed')::int`,
        })
        .from(bookings);

      const botUsername = await getBotUsername();
      return Response.json({
        ok: true,
        telegramConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_MODERATOR_CHAT_ID),
        botUsername,
        stats: {
          total: totals?.total ?? 0,
          sent: totals?.sent ?? 0,
          failed: totals?.failed ?? 0,
        },
        rooms,
        bookings: list,
      });
    }

    if (action === "toggle") {
      const room = getRoom(body?.roomId);
      if (!room) return Response.json({ ok: false, error: "Номер не найден." }, { status: 400 });
      const map = await getStatusMap();
      const next = map[room.id] === "busy" ? "free" : "busy";
      await db
        .update(roomStatuses)
        .set({ status: next, updatedAt: new Date() })
        .where(eq(roomStatuses.roomId, room.id));
      return Response.json({ ok: true, roomId: room.id, status: next, rooms: { ...map, [room.id]: next } });
    }

    if (action === "ping") {
      try {
        await sendModeratorPing();
        return Response.json({ ok: true });
      } catch (error) {
        const raw = error instanceof Error ? error.message : "Telegram error";
        return Response.json({ ok: false, error: friendlyTelegramError(raw), detail: raw }, { status: 502 });
      }
    }

    if (action === "resend") {
      const bookingId = Number(body?.bookingId);
      if (!Number.isInteger(bookingId) || bookingId < 1) {
        return Response.json({ ok: false, error: "Заявка не найдена." }, { status: 400 });
      }
      const [row] = await db.select().from(bookings).where(eq(bookings.id, bookingId));
      if (!row) return Response.json({ ok: false, error: "Заявка не найдена." }, { status: 404 });
      const delivery = await deliverBooking(row);
      if (!delivery.ok) {
        return Response.json({ ok: false, error: delivery.error }, { status: 502 });
      }
      return Response.json({ ok: true });
    }

    return Response.json({ ok: false, error: "Неизвестное действие." }, { status: 400 });
  } catch (error) {
    console.error("admin failed", error instanceof Error ? error.name : "error");
    return Response.json({ ok: false, error: "Панель временно недоступна." }, { status: 500 });
  }
}
