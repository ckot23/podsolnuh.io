import { db } from "@/db";
import { ORDER_STATUSES, orders, type OrderStatus } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

const ADMIN_TOKEN = process.env.ADMIN_API_TOKEN ?? "";

function authorized(request: NextRequest): boolean {
  if (!ADMIN_TOKEN) return true;
  return request.headers.get("x-admin-token") === ADMIN_TOKEN;
}

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  if (!authorized(request)) {
    return Response.json({ ok: false, error: "Неверный x-admin-token" }, { status: 401 });
  }

  const { id } = await context.params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId) || orderId <= 0) {
    return Response.json({ ok: false, error: "Некорректный id" }, { status: 400 });
  }

  let body: { status?: string };
  try {
    body = (await request.json()) as { status?: string };
  } catch {
    return Response.json({ ok: false, error: "Ожидался JSON" }, { status: 400 });
  }

  const status = body.status as OrderStatus | undefined;
  if (!status || !ORDER_STATUSES.includes(status)) {
    return Response.json({ ok: false, error: "Недопустимый статус" }, { status: 400 });
  }

  const [updated] = await db
    .update(orders)
    .set({ status, updatedAt: new Date() })
    .where(eq(orders.id, orderId))
    .returning();

  if (!updated) {
    return Response.json({ ok: false, error: "Заказ не найден" }, { status: 404 });
  }

  return Response.json({ ok: true, order: updated });
}
