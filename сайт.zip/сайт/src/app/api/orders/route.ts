import { db } from "@/db";
import { orders, type NewOrder, type OrderItemRow } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

const ADMIN_TOKEN = process.env.ADMIN_API_TOKEN ?? "";

function authorized(request: NextRequest): boolean {
  if (!ADMIN_TOKEN) return true; // локальная разработка без токена
  return request.headers.get("x-admin-token") === ADMIN_TOKEN;
}

function bad(message: string, status = 400) {
  return Response.json({ ok: false, error: message }, { status });
}

type IncomingItem = Partial<OrderItemRow>;

type IncomingBody = {
  externalId?: string;
  source?: string;
  customer?: string;
  phone?: string;
  username?: string | null;
  telegramId?: string | number | null;
  delivery?: string;
  address?: string | null;
  payment?: string;
  promo?: string | null;
  discount?: number;
  deliveryFee?: number;
  total?: number;
  comment?: string | null;
  status?: string;
  placedAt?: string;
  items?: IncomingItem[];
};

/** Приём заказа из Telegram-бота (coffee_bot/services.py). */
export async function POST(request: NextRequest) {
  if (!authorized(request)) return bad("Неверный x-admin-token", 401);

  let body: IncomingBody;
  try {
    body = (await request.json()) as IncomingBody;
  } catch {
    return bad("Ожидался JSON");
  }

  if (!body.externalId) return bad("externalId обязателен");
  if (!body.customer) return bad("customer обязателен");
  if (!Array.isArray(body.items) || body.items.length === 0) return bad("items не могут быть пустыми");

  const items: OrderItemRow[] = body.items.map((item) => ({
    title: String(item.title ?? "Позиция"),
    emoji: String(item.emoji ?? "☕"),
    size: String(item.size ?? ""),
    price: Number(item.price ?? 0),
    qty: Number(item.qty ?? 1),
  }));

  const total =
    Number.isFinite(body.total) && body.total != null
      ? Math.round(Number(body.total))
      : items.reduce((sum, item) => sum + item.price * item.qty, 0) +
        Math.round(Number(body.deliveryFee ?? 0)) -
        Math.round(Number(body.discount ?? 0));

  const payload: NewOrder = {
    externalId: String(body.externalId),
    source: String(body.source ?? "telegram"),
    customer: String(body.customer),
    phone: String(body.phone ?? "не указан"),
    username: body.username ? String(body.username) : null,
    telegramId: body.telegramId != null ? String(body.telegramId) : null,
    delivery: String(body.delivery ?? "pickup"),
    address: body.address ? String(body.address) : null,
    payment: String(body.payment ?? "card"),
    promo: body.promo ? String(body.promo) : null,
    discount: Math.round(Number(body.discount ?? 0)),
    deliveryFee: Math.round(Number(body.deliveryFee ?? 0)),
    total: Math.max(total, 0),
    comment: body.comment ? String(body.comment) : null,
    status: String(body.status ?? "new"),
    items,
    placedAt: body.placedAt ? new Date(body.placedAt) : new Date(),
  };

  const [saved] = await db
    .insert(orders)
    .values(payload)
    .onConflictDoUpdate({
      target: orders.externalId,
      set: {
        customer: payload.customer,
        phone: payload.phone,
        delivery: payload.delivery,
        address: payload.address,
        payment: payload.payment,
        promo: payload.promo,
        discount: payload.discount,
        deliveryFee: payload.deliveryFee,
        total: payload.total,
        comment: payload.comment,
        items: payload.items,
        updatedAt: new Date(),
      },
    })
    .returning();

  return Response.json({ ok: true, order: saved }, { status: 201 });
}

/** Список заказов + агрегаты для панели. */
export async function GET(request: NextRequest) {
  if (!authorized(request)) return bad("Неверный x-admin-token", 401);

  const status = request.nextUrl.searchParams.get("status");
  const limit = Math.min(Number(request.nextUrl.searchParams.get("limit") ?? 50) || 50, 200);

  const rows = status
    ? await db.select().from(orders).where(sql`${orders.status} = ${status}`).orderBy(desc(orders.placedAt)).limit(limit)
    : await db.select().from(orders).orderBy(desc(orders.placedAt)).limit(limit);

  const revenue = rows
    .filter((row) => row.status !== "canceled")
    .reduce((sum, row) => sum + row.total, 0);

  return Response.json({
    ok: true,
    count: rows.length,
    revenue,
    orders: rows,
  });
}
