import { clientIp, rateLimit, sameOrigin } from "@/lib/auth";
import { deliverBooking, parseBookingBody, roomIsBusy, saveBooking } from "@/lib/booking";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return Response.json({ ok: false, error: "Заявку можно отправить только с сайта." }, { status: 403 });
  }
  if (!rateLimit(`book:${clientIp(request)}`)) {
    return Response.json(
      { ok: false, error: "Слишком много заявок. Позвоните: 8 918 116-45-54." },
      { status: 429 },
    );
  }

  const body = await request.json().catch(() => null);
  const parsed = parseBookingBody(body);
  if (!parsed.ok) {
    if (parsed.honeypot) return Response.json({ ok: true, telegram: true });
    return Response.json({ ok: false, error: parsed.error, field: parsed.field }, { status: 400 });
  }

  try {
    if (parsed.data.roomId && (await roomIsBusy(parsed.data.roomId))) {
      return Response.json(
        { ok: false, error: "Этот номер сейчас занят. Выберите другой или позвоните.", field: "room" },
        { status: 409 },
      );
    }

    const row = await saveBooking(parsed.data);
    const delivery = await deliverBooking(row);
    if (!delivery.ok) {
      return Response.json({
        ok: true,
        id: row.id,
        telegram: false,
        warning: delivery.error,
      });
    }
    return Response.json({ ok: true, id: row.id, telegram: true });
  } catch (error) {
    console.error("booking save failed", error instanceof Error ? error.name : "error");
    return Response.json(
      { ok: false, error: "Не удалось сохранить заявку. Позвоните: 8 918 116-45-54." },
      { status: 500 },
    );
  }
}
