import { Site } from "@/components/site";
import { getStatusMap } from "@/lib/booking";
import { emptyStatusMap } from "@/lib/rooms";

export const dynamic = "force-dynamic";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "LodgingBusiness",
  name: "Посуточная аренда квартир и номеров — Топольки, Краснодар",
  description: "Квартиры-студии и номера посуточно напрямую от собственника. Кухня в каждом номере, парковка, видеонаблюдение.",
  telephone: "+7 918 116-45-54",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Краснодар",
    streetAddress: "СТ4 Топольки, ул. Цветочная 162 / ул. Железнодорожная 180",
    addressCountry: "RU",
  },
  priceRange: "2000-3000 RUB",
};

export default async function HomePage() {
  let statuses = emptyStatusMap();
  try {
    statuses = await getStatusMap();
  } catch {
    statuses = emptyStatusMap();
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Site initialStatuses={statuses} />
    </>
  );
}
