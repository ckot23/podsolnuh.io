"use client";

import { useEffect, useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { ORDER_STATUSES, STATUS_LABELS, STATUS_STYLES, type OrderStatus } from "@/db/schema";

export type AdminOrder = {
  id: number;
  externalId: string;
  customer: string;
  phone: string;
  username: string | null;
  telegramId: string | null;
  delivery: string;
  address: string | null;
  payment: string;
  promo: string | null;
  discount: number;
  deliveryFee: number;
  total: number;
  comment: string | null;
  status: OrderStatus;
  items: { title: string; emoji: string; size: string; price: number; qty: number }[];
  placedAt: string;
};

const DELIVERY_LABELS: Record<string, string> = {
  pickup: "🚶 Самовывоз",
  courier: "🛵 Доставка",
};

const PAYMENT_LABELS: Record<string, string> = {
  cash: "💵 Наличные",
  card: "💳 Карта при получении",
  online: "📱 СБП",
};

function rub(value: number): string {
  return `${value.toLocaleString("ru-RU")} ₽`;
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "только что";
  if (minutes < 60) return `${minutes} мин назад`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} ч назад`;
  return new Date(iso).toLocaleString("ru-RU", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export default function OrdersClient({ initialOrders }: { initialOrders: AdminOrder[] }) {
  const router = useRouter();
  const [orders, setOrders] = useState<AdminOrder[]>(initialOrders);
  const [filter, setFilter] = useState<OrderStatus | "all">("all");
  const [pending, startTransition] = useTransition();
  const [busyId, setBusyId] = useState<number | null>(null);

  useEffect(() => {
    setOrders(initialOrders);
  }, [initialOrders]);

  useEffect(() => {
    const timer = setInterval(() => startTransition(() => router.refresh()), 20000);
    return () => clearInterval(timer);
  }, [router]);

  const stats = useMemo(() => {
    const active = orders.filter((order) => order.status !== "canceled");
    return {
      total: orders.length,
      revenue: active.reduce((sum, order) => sum + order.total, 0),
      avg: active.length ? Math.round(active.reduce((sum, order) => sum + order.total, 0) / active.length) : 0,
      newCount: orders.filter((order) => order.status === "new").length,
    };
  }, [orders]);

  async function updateStatus(id: number, status: OrderStatus) {
    setBusyId(id);
    const previous = orders;
    setOrders((current) => current.map((order) => (order.id === id ? { ...order, status } : order)));
    try {
      const response = await fetch(`/api/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!response.ok) throw new Error("Не удалось обновить статус");
      startTransition(() => router.refresh());
    } catch {
      setOrders(previous);
    } finally {
      setBusyId(null);
    }
  }

  const visible = filter === "all" ? orders : orders.filter((order) => order.status === filter);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
          <p className="text-sm text-stone-500">Заказов всего</p>
          <p className="mt-1 text-3xl font-bold">{stats.total}</p>
        </div>
        <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
          <p className="text-sm text-stone-500">Выручка</p>
          <p className="mt-1 text-3xl font-bold text-emerald-700">{rub(stats.revenue)}</p>
        </div>
        <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
          <p className="text-sm text-stone-500">Средний чек</p>
          <p className="mt-1 text-3xl font-bold">{rub(stats.avg)}</p>
        </div>
        <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
          <p className="text-sm text-stone-500">Новых заказов</p>
          <p className={`mt-1 text-3xl font-bold ${stats.newCount ? "text-amber-600" : ""}`}>{stats.newCount}</p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setFilter("all")}
          className={`rounded-full px-4 py-2 text-sm font-medium transition ${
            filter === "all" ? "bg-stone-900 text-white" : "bg-white text-stone-700 ring-1 ring-stone-200 hover:bg-stone-100"
          }`}
        >
          Все ({orders.length})
        </button>
        {ORDER_STATUSES.map((status) => {
          const count = orders.filter((order) => order.status === status).length;
          return (
            <button
              key={status}
              onClick={() => setFilter(status)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                filter === status ? "bg-stone-900 text-white" : "bg-white text-stone-700 ring-1 ring-stone-200 hover:bg-stone-100"
              }`}
            >
              {STATUS_LABELS[status]} ({count})
            </button>
          );
        })}
        <span className="ml-auto text-xs text-stone-500">
          {pending ? "обновляем…" : "автообновление каждые 20 секунд"}
        </span>
      </div>

      {visible.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed border-stone-300 bg-white p-12 text-center">
          <p className="text-4xl">☕</p>
          <h3 className="mt-4 text-lg font-semibold">Заказов пока нет</h3>
          <p className="mx-auto mt-2 max-w-lg text-sm text-stone-600">
            Запустите бота (<code>coffee_bot/main.py</code> в PyCharm), сделайте тестовый заказ в Telegram —
            и он появится здесь автоматически. Не забудьте в <code>.env</code> бота указать{" "}
            <code>ADMIN_API_URL</code> и <code>ADMIN_API_TOKEN</code>.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {visible.map((order) => (
            <article key={order.id} className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3">
                    <h3 className="text-lg font-bold">Заказ #{order.id}</h3>
                    <span
                      className={`rounded-full px-3 py-1 text-xs font-semibold ring-1 ${
                        STATUS_STYLES[order.status] ?? "bg-stone-100 text-stone-700 ring-stone-200"
                      }`}
                    >
                      {STATUS_LABELS[order.status] ?? order.status}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-stone-500">
                    {timeAgo(order.placedAt)} · {order.externalId} ·{" "}
                    {order.username ? `@${order.username}` : "без username"}
                    {order.telegramId ? ` · ID ${order.telegramId}` : ""}
                  </p>
                </div>
                <p className="text-2xl font-bold text-stone-900">{rub(order.total)}</p>
              </div>

              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <ul className="space-y-1 text-sm">
                  {order.items.map((item, index) => (
                    <li key={`${order.id}-${index}`} className="flex justify-between gap-3 border-b border-stone-100 pb-1">
                      <span>
                        {item.emoji} {item.title}
                        {item.size ? <span className="text-stone-500"> · {item.size}</span> : null}
                        <span className="text-stone-500"> ×{item.qty}</span>
                      </span>
                      <span className="font-medium">{rub(item.price * item.qty)}</span>
                    </li>
                  ))}
                  {order.discount > 0 ? (
                    <li className="flex justify-between text-amber-700">
                      <span>Скидка {order.promo}</span>
                      <span>−{rub(order.discount)}</span>
                    </li>
                  ) : null}
                  {order.deliveryFee > 0 ? (
                    <li className="flex justify-between text-stone-600">
                      <span>Доставка</span>
                      <span>{rub(order.deliveryFee)}</span>
                    </li>
                  ) : null}
                </ul>
                <div className="space-y-1 text-sm text-stone-700">
                  <p>
                    <b>Гость:</b> {order.customer}
                  </p>
                  <p>
                    <b>Телефон:</b> {order.phone}
                  </p>
                  <p>
                    <b>Получение:</b> {DELIVERY_LABELS[order.delivery] ?? order.delivery}
                    {order.address ? ` → ${order.address}` : ""}
                  </p>
                  <p>
                    <b>Оплата:</b> {PAYMENT_LABELS[order.payment] ?? order.payment}
                  </p>
                  {order.comment ? (
                    <p>
                      <b>Пожелания:</b> {order.comment}
                    </p>
                  ) : null}
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-2 border-t border-stone-100 pt-4">
                {ORDER_STATUSES.filter((status) => status !== order.status).map((status) => (
                  <button
                    key={status}
                    disabled={busyId === order.id}
                    onClick={() => updateStatus(order.id, status)}
                    className={`rounded-lg px-3 py-1.5 text-sm font-medium transition disabled:opacity-50 ${
                      status === "canceled"
                        ? "bg-rose-50 text-rose-700 ring-1 ring-rose-200 hover:bg-rose-100"
                        : status === "done"
                          ? "bg-stone-100 text-stone-700 ring-1 ring-stone-200 hover:bg-stone-200"
                          : "bg-amber-50 text-amber-800 ring-1 ring-amber-200 hover:bg-amber-100"
                    }`}
                  >
                    → {STATUS_LABELS[status]}
                  </button>
                ))}
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
