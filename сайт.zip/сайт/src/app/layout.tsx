import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Квартиры и номера посуточно в Краснодаре — от собственника",
  description:
    "Посуточная аренда квартир и номеров в Краснодаре от 2 000 ₽/сутки. Напрямую от собственника, без комиссий. Кухня в каждом номере, парковка, видеонаблюдение. 80 м до краевого призывного пункта.",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "Квартиры и номера посуточно в Краснодаре — от собственника",
    description: "От 2 000 ₽/сутки. Кухня, парковка, видеонаблюдение. Заявка сразу приходит собственнику в Telegram.",
    locale: "ru_RU",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#f7f3ec",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
