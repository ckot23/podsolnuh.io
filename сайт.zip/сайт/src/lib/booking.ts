import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings, roomStatuses, type BookingRecord } from "@/db/schema";
import {
  addMonthsISO,
  cleanText,
  datesLabel,
  isISODate,
  moscowTodayISO,
  nightsBetween,
  normalizePhone,
} from "@/lib/dates";
import { GUEST_OPTIONS, ROOMS, getRoom, guestsCount } from "@/lib/rooms";
import { friendlyTelegramError, sendBookingNotification } from "@/lib/telegram";

export type FieldName = "name" | "phone" | "dates" | "guests" | "room" | "consent" | "comment";

export type NormalizedBooking = {
  name: string;
  phone: string;
  checkIn: string;
  checkOut: string;
  datesLabel: string;
  nights: number;
  guests: string;
  roomId: string | null;
  roomLabel: string | null;
  comment: string | null;
  estimateRub: number | null;
};

type ParseResult =
  | { ok: true; data: NormalizedBooking }
  | { ok: false; error: string; field?: FieldName; honeypot?: boolean };

export function parseBookingBody(body: unknown): ParseResult {
  if (!body || typeof body !== "object") {
    return { ok: false, error: "Некорректная заявка" };
  }
  const input = body as Record<string, unknown>;
  const website = typeof input.website === "string" ? input.website.trim() : "";
  if (website) return { ok: false, error: "spam", honeypot: true };

  if (input.consent !== true) {
    return { ok: false, error: "Нужно согласие на обработку данных.", field: "consent" };
  }

  const name = cleanText(typeof input.name === "string" ? input.name : "", 80);
  if (name.length < 2 || !/\p{L}/u.test(name)) {
    return { ok: false, error: "Представьтесь, пожалуйста.", field: "name" };
  }

  const phone = cleanText(typeof input.phone === "string" ? input.phone : "", 40);
  if (!normalizePhone(phone)) {
    return { ok: false, error: "Нужен телефон, чтобы перезвонить.", field: "phone" };
  }

  const checkIn = typeof input.checkIn === "string" ? input.checkIn : "";
  const checkOut = typeof input.checkOut === "string" ? input.checkOut : "";
  if (!isISODate(checkIn) || !isISODate(checkOut)) {
    return { ok: false, error: "Выберите даты заезда и выезда.", field: "dates" };
  }
  const today = moscowTodayISO();
  const maxDate = addMonthsISO(today, 18);
  if (checkIn < today || checkOut <= checkIn || checkOut > maxDate) {
    return { ok: false, error: "Проверьте даты: заезд не раньше сегодня, выезд позже заезда.", field: "dates" };
  }
  const nights = nightsBetween(checkIn, checkOut);
  if (nights < 1 || nights > 60) {
    return { ok: false, error: "Можно забронировать от 1 до 60 суток.", field: "dates" };
  }

  const guests = typeof input.guests === "string" ? input.guests : "";
  if (!GUEST_OPTIONS.includes(guests as (typeof GUEST_OPTIONS)[number])) {
    return { ok: false, error: "Укажите количество гостей.", field: "guests" };
  }

  const roomIdRaw = typeof input.roomId === "string" ? input.roomId : "";
  const room = roomIdRaw ? getRoom(roomIdRaw) : null;
  if (roomIdRaw && !room) {
    return { ok: false, error: "Такого номера нет.", field: "room" };
  }

  const commentRaw = cleanText(typeof input.comment === "string" ? input.comment : "", 500);
  const estimateRub = room ? room.priceFrom * nights : null;

  return {
    ok: true,
    data: {
      name,
      phone,
      checkIn,
      checkOut,
      datesLabel: datesLabel(checkIn, checkOut),
      nights,
      guests,
      roomId: room?.id ?? null,
      roomLabel: room ? `${room.shortLabel} · от ${room.priceFrom.toLocaleString("ru-RU")} ₽` : null,
      comment: commentRaw || null,
      estimateRub,
    },
  };
}

export async function ensureRoomRows() {
  const existing = await db.select().from(roomStatuses);
  const have = new Set(existing.map((row) => row.roomId));
  const missing = ROOMS.filter((room) => !have.has(room.id)).map((room) => ({
    roomId: room.id,
    status: "free",
  }));
  if (missing.length) await db.insert(roomStatuses).values(missing);
}

export async function getStatusMap() {
  await ensureRoomRows();
  const rows = await db.select().from(roomStatuses);
  const map: Record<string, "free" | "busy"> = {};
  for (const room of ROOMS) {
    const row = rows.find((item) => item.roomId === room.id);
    map[room.id] = row?.status === "busy" ? "busy" : "free";
  }
  return map;
}

export async function roomIsBusy(roomId: string) {
  const map = await getStatusMap();
  return map[roomId] === "busy";
}

export async function saveBooking(data: NormalizedBooking) {
  const [row] = await db
    .insert(bookings)
    .values({
      name: data.name,
      phone: data.phone,
      checkIn: data.checkIn,
      checkOut: data.checkOut,
      datesLabel: data.datesLabel,
      nights: data.nights,
      guests: data.guests,
      roomId: data.roomId,
      roomLabel: data.roomLabel,
      comment: data.comment,
      estimateRub: data.estimateRub,
      telegramStatus: "pending",
    })
    .returning();
  return row;
}

export async function deliverBooking(row: BookingRecord) {
  try {
    const result = await sendBookingNotification(row);
    await db
      .update(bookings)
      .set({
        telegramStatus: "sent",
        telegramMessageId: String(result.message_id),
        telegramError: null,
      })
      .where(eq(bookings.id, row.id));
    return { ok: true as const };
  } catch (error) {
    const raw = error instanceof Error ? error.message : "Telegram error";
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const safe = token ? raw.split(token).join("[token]") : raw;
    await db
      .update(bookings)
      .set({ telegramStatus: "failed", telegramError: safe.slice(0, 500) })
      .where(eq(bookings.id, row.id));
    return { ok: false as const, error: friendlyTelegramError(safe) };
  }
}

export function guestCountLabel(guests: string) {
  const count = guestsCount(guests);
  return count ? String(count) : guests;
}
