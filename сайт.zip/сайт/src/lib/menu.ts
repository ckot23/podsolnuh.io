export type MenuItem = {
  id: number;
  title: string;
  emoji: string;
  description: string;
  prices: number[];
  unit?: string;
};

export type MenuCategory = {
  id: number;
  title: string;
  emoji: string;
  items: MenuItem[];
};

const money = (value: number) => `${value} ₽`;

export function formatPrice(value: number): string {
  return `${value.toLocaleString("ru-RU")} ₽`;
}

export function priceLabel(item: MenuItem): string {
  if (item.prices.length === 1) return money(item.prices[0]);
  return `от ${money(Math.min(...item.prices))}`;
}

export const MENU: MenuCategory[] = [
  {
    id: 1,
    title: "Кофе",
    emoji: "☕",
    items: [
      { id: 101, title: "Эспрессо", emoji: "☕", description: "Brazil + Ethiopia, 100% арабика свежей обжарки.", prices: [150], unit: "30 мл" },
      { id: 102, title: "Американо", emoji: "🍵", description: "Мягкий вкус без горечи.", prices: [170, 200, 230] },
      { id: 103, title: "Капучино", emoji: "🥛", description: "1/3 эспрессо и 2/3 бархатного молока.", prices: [220, 260, 290] },
      { id: 104, title: "Латте", emoji: "🍶", description: "Молочный, нежный, с пенкой 1 см.", prices: [240, 280, 310] },
      { id: 105, title: "Флэт уайт", emoji: "🤍", description: "Двойной эспрессо и микропенка.", prices: [260, 300, 330] },
      { id: 106, title: "Раф", emoji: "🍦", description: "Сливки, ванильный сахар и эспрессо.", prices: [280, 320, 350] },
      { id: 107, title: "Мокка", emoji: "🍫", description: "Эспрессо, молоко и бельгийский шоколад.", prices: [290, 330, 360] },
      { id: 108, title: "Карамельный макьято", emoji: "🍯", description: "Ванильное молоко, эспрессо, солёная карамель.", prices: [300, 340, 370] },
      { id: 109, title: "Кортадо", emoji: "🥃", description: "Испанская классика: 50/50 с молоком.", prices: [210], unit: "120 мл" },
    ],
  },
  {
    id: 2,
    title: "Не кофе",
    emoji: "🧋",
    items: [
      { id: 201, title: "Матча-латте", emoji: "🍵", description: "Церемониальная матча и молоко на выбор.", prices: [300, 340, 380] },
      { id: 202, title: "Какао", emoji: "🍫", description: "Горячий шоколад из какао 70%.", prices: [260, 300, 330] },
      { id: 203, title: "Облепиховый чай", emoji: "🍊", description: "Облепиха, апельсин, мёд, специи.", prices: [240, 280, 320] },
      { id: 204, title: "Чёрный чай", emoji: "🫖", description: "Ассам или Эрл Грей, листовой.", prices: [220], unit: "чайник 600 мл" },
      { id: 205, title: "Фильтр V60", emoji: "⚗️", description: "Спешелти-зерно недели, завариваем вручную.", prices: [290], unit: "300 мл" },
    ],
  },
  {
    id: 3,
    title: "Холодные напитки",
    emoji: "❄️",
    items: [
      { id: 301, title: "Айс-латте", emoji: "🧊", description: "Холодное молоко, эспрессо, лёд.", prices: [260, 300, 330] },
      { id: 302, title: "Колд брю", emoji: "🖤", description: "12 часов холодной экстракции.", prices: [300, 340, 380] },
      { id: 303, title: "Айс-матча", emoji: "🥤", description: "Матча, молоко, лёд.", prices: [320, 360, 400] },
      { id: 304, title: "Домашний лимонад", emoji: "🍋", description: "Манго-маракуйя или клубника-базилик.", prices: [250], unit: "400 мл" },
    ],
  },
  {
    id: 4,
    title: "Десерты и снеки",
    emoji: "🥐",
    items: [
      { id: 401, title: "Круассан классический", emoji: "🥐", description: "Слоёный, из печи каждое утро.", prices: [180] },
      { id: 402, title: "Круассан с миндалём", emoji: "🌰", description: "Миндальный крем и лепестки миндаля.", prices: [240] },
      { id: 403, title: "Чизкейк Нью-Йорк", emoji: "🍰", description: "Плотный, на песочной основе, с ягодами.", prices: [320] },
      { id: 404, title: "Синнабон", emoji: "🌀", description: "Корица и крем-чиз, подаём тёплым.", prices: [290] },
      { id: 405, title: "Эклер", emoji: "🍮", description: "Фисташковый или шоколадный крем.", prices: [230] },
      { id: 406, title: "Банановый хлеб", emoji: "🍌", description: "Веган, без рафинированного сахара.", prices: [210] },
      { id: 407, title: "Тост с авокадо", emoji: "🥑", description: "Хлеб на закваске, авокадо, яйцо пашот.", prices: [420] },
    ],
  },
];

export const SIZES = ["S · 250 мл", "M · 350 мл", "L · 450 мл"];

export const PROMOS = [
  { code: "КОФЕ10", percent: 10 },
  { code: "ПЕРВЫЙ15", percent: 15 },
  { code: "ДРУГ", percent: 20 },
];
