export const TELEGRAM_URL = "https://t.me/ckot_23";
export const TELEGRAM_HANDLE = "@ckot_23";
export const WHATSAPP_URL = "https://wa.me/79882443223";
export const WHATSAPP_NUMBER = "79882443223";
export const PHONE_PRIMARY = "+79181164554";
export const PHONE_PRIMARY_LABEL = "8 918 116-45-54";
export const PHONE_SECONDARY = "+79189451223";
export const PHONE_SECONDARY_LABEL = "8 918 945-12-23";

export type Room = {
  id: string;
  name: string;
  shortLabel: string;
  address: string;
  fullAddress: string;
  priceFrom: number;
  maxGuests: number;
  guestsLabel: string;
  description: string;
  image: string;
  imageFile: string;
  alt: string;
  amenities: string[];
};

export const ROOMS: Room[] = [
  {
    id: "studio-4",
    name: "Студия с кухней",
    shortLabel: "Студия с кухней · Цветочная 162",
    address: "Цветочная 162",
    fullAddress: "Краснодар, СТ4 Топольки, ул. Цветочная, 162",
    priceFrom: 2500,
    maxGuests: 4,
    guestsLabel: "до 4 гостей",
    description:
      "Двуспальная кровать, диван и кресло-кровать. Кухонная зона с техникой и посудой, душ и туалет.",
    image: "/images/room-studio-4.jpg",
    imageFile: "images/room-studio-4.jpg",
    alt: "Студия с кухней: двуспальная кровать, диван и кухонная зона",
    amenities: ["Кухня", "Холодильник", "Посуда", "Душ / туалет"],
  },
  {
    id: "studio-comfort",
    name: "Студия комфорт",
    shortLabel: "Студия комфорт · Цветочная 162",
    address: "Цветочная 162",
    fullAddress: "Краснодар, СТ4 Топольки, ул. Цветочная, 162",
    priceFrom: 3000,
    maxGuests: 4,
    guestsLabel: "до 4 гостей",
    description:
      "Просторная студия: двуспальная кровать, диван, кресло-кровать. Полноценная кухня, душ и туалет.",
    image: "/images/room-studio-comfort.jpg",
    imageFile: "images/room-studio-comfort.jpg",
    alt: "Студия комфорт: просторная комната с кухней и обеденным столом",
    amenities: ["Кухня", "Холодильник", "Посуда", "Душ / туалет"],
  },
  {
    id: "apart-2",
    name: "Апартаменты",
    shortLabel: "Апартаменты · Железнодорожная 180",
    address: "Железнодорожная 180",
    fullAddress: "Краснодар, СТ4 Топольки, ул. Железнодорожная, 180",
    priceFrom: 2000,
    maxGuests: 2,
    guestsLabel: "до 2 гостей",
    description:
      "Уютный номер для двоих с кухонной зоной, техникой и посудой. Двуспальная кровать, душ и туалет.",
    image: "/images/room-apart-2.jpg",
    imageFile: "images/room-apart-2.jpg",
    alt: "Апартаменты для двоих: аккуратная комната с кухонной зоной",
    amenities: ["Кухня", "Холодильник", "Посуда", "Душ / туалет"],
  },
  {
    id: "kitchen-3",
    name: "Номер с собственной кухней",
    shortLabel: "Номер с кухней · Железнодорожная 180",
    address: "Железнодорожная 180",
    fullAddress: "Краснодар, СТ4 Топольки, ул. Железнодорожная, 180",
    priceFrom: 2500,
    maxGuests: 3,
    guestsLabel: "до 3 гостей",
    description:
      "Двуспальная и односпальная кровати, собственная кухонная зона с техникой и посудой, душ и туалет.",
    image: "/images/room-kitchen-3.jpg",
    imageFile: "images/room-kitchen-3.jpg",
    alt: "Номер с собственной кухней: двуспальная и односпальная кровати",
    amenities: ["Кухня", "Холодильник", "Посуда", "Душ / туалет"],
  },
];

export const GUEST_OPTIONS = ["1", "2", "3", "4", "5+"] as const;

export function getRoom(id: string | null | undefined) {
  if (!id) return null;
  return ROOMS.find((room) => room.id === id) ?? null;
}

export function guestsCount(guests: string) {
  if (guests === "5+") return 5;
  const value = Number(guests);
  return Number.isFinite(value) ? value : 0;
}

export function isOverCapacity(roomId: string | null | undefined, guests: string) {
  const room = getRoom(roomId);
  if (!room) return false;
  return guestsCount(guests) > room.maxGuests;
}

export type RoomStatus = "free" | "busy";
export type StatusMap = Record<string, RoomStatus>;

export function emptyStatusMap(): StatusMap {
  return Object.fromEntries(ROOMS.map((room) => [room.id, "free"])) as StatusMap;
}
