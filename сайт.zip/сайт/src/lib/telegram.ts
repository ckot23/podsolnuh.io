import { readFile } from "fs/promises";
import path from "path";
import { datesLabel, formatMoscow, formatPhonePretty, formatRub, normalizePhone } from "@/lib/dates";
import { getRoom, guestsCount, isOverCapacity } from "@/lib/rooms";

export type TelegramPayload = {
  id: number;
  name: string;
  phone: string;
  checkIn?: string | null;
  checkOut?: string | null;
  datesLabel?: string | null;
  nights?: number | null;
  guests: string;
  roomId?: string | null;
  roomLabel?: string | null;
  comment?: string | null;
  estimateRub?: number | null;
  createdAt?: Date | string | null;
};

function redact(text: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  return token ? text.split(token).join("[token]") : text;
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

export function friendlyTelegramError(description: string) {
  const text = description.toLowerCase();
  if (text.includes("unauthorized")) return "Токен бота недействителен. Заявка сохранена на сайте.";
  if (text.includes("blocked") || text.includes("initiate") || text.includes("chat not found") || text.includes("peer")) {
    return "Заявка сохранена. В Telegram она пока не ушла — напишите @ckot_23, мы подтвердим бронь.";
  }
  return "Не удалось доставить заявку в Telegram. Она сохранена — можно написать @ckot_23.";
}

let cachedBotUsername: string | null = null;

export async function getBotUsername() {
  if (cachedBotUsername) return cachedBotUsername;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/getMe`, {
      cache: "no-store",
      signal: AbortSignal.timeout(8_000),
    });
    const data = (await response.json()) as { ok?: boolean; result?: { username?: string } };
    cachedBotUsername = data.ok ? data.result?.username || null : null;
    return cachedBotUsername;
  } catch {
    return null;
  }
}

export async function sendModeratorPing() {
  return telegramRequest("sendMessage", {
    text: "Проверка связи с сайтом «Топольки». Если это сообщение видно, заявки на бронь будут приходить сюда.",
    disable_web_page_preview: true,
  });
}

export function buildModeratorMessage(booking: TelegramPayload) {
  const room = getRoom(booking.roomId);
  const digits = normalizePhone(booking.phone);
  const pretty = digits ? formatPhonePretty(digits) : booking.phone;
  const label =
    booking.datesLabel ||
    (booking.checkIn && booking.checkOut ? datesLabel(booking.checkIn, booking.checkOut) : "не указаны");
  const lines = [
    "🏠 <b>Новая заявка на бронь</b>",
    "Топольки · Краснодар · с сайта",
    "",
    `👤 <b>Имя:</b> ${escapeHtml(booking.name)}`,
    `📞 <b>Телефон:</b> ${escapeHtml(pretty)}`,
    `📅 <b>Даты:</b> ${escapeHtml(label)}`,
    `👥 <b>Гостей:</b> ${escapeHtml(booking.guests)}`,
    `🛏 <b>Номер:</b> ${escapeHtml(booking.roomLabel || "не выбран — подобрать")}`,
  ];

  if (room) lines.push(`📍 <b>Адрес:</b> ${escapeHtml(room.fullAddress)}`);
  if (booking.estimateRub && booking.nights && room) {
    lines.push(
      `💰 <b>Ориентир:</b> от ${escapeHtml(formatRub(booking.estimateRub))} (${escapeHtml(formatRub(room.priceFrom))} × ${booking.nights} сут., не финальная цена)`,
    );
  }
  if (isOverCapacity(booking.roomId, booking.guests)) {
    lines.push(
      `⚠️ Гостей ${guestsCount(booking.guests)} — больше, чем мест в номере (до ${room?.maxGuests ?? "—"})`,
    );
  }
  if (booking.comment) lines.push(`💬 <b>Комментарий:</b> ${escapeHtml(booking.comment)}`);

  const created = booking.createdAt ? new Date(booking.createdAt) : new Date();
  lines.push("");
  lines.push(`🕐 ${escapeHtml(formatMoscow(created))}`);
  lines.push(`Заявка №${booking.id}`);
  return lines.join("\n").slice(0, 1000);
}

async function telegramRequest(method: string, body: FormData | Record<string, unknown>) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_MODERATOR_CHAT_ID;
  if (!token || !chatId) {
    throw new Error("Telegram-бот не настроен");
  }

  let payload: BodyInit;
  let headers: HeadersInit | undefined;
  if (body instanceof FormData) {
    body.set("chat_id", chatId);
    payload = body;
  } else {
    payload = JSON.stringify({ ...body, chat_id: chatId });
    headers = { "Content-Type": "application/json" };
  }

  let response: Response;
  try {
    response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers,
      body: payload,
      signal: AbortSignal.timeout(12_000),
      cache: "no-store",
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "сеть недоступна";
    throw new Error(redact(message).includes("timeout") ? "Telegram не ответил вовремя" : "Нет связи с Telegram");
  }

  const data = (await response.json().catch(() => null)) as
    | { ok: true; result: { message_id: number } }
    | { ok: false; description?: string }
    | null;

  if (!data || !data.ok) {
    throw new Error(data?.description || "Telegram отклонил сообщение");
  }
  return data.result;
}

function replyMarkup(phone: string) {
  const digits = normalizePhone(phone);
  if (!digits) return undefined;
  return {
    inline_keyboard: [[{ text: "Написать гостю в WhatsApp", url: `https://wa.me/${digits}` }]],
  };
}

export async function sendBookingNotification(booking: TelegramPayload) {
  const caption = buildModeratorMessage(booking);
  const markup = replyMarkup(booking.phone);
  const room = getRoom(booking.roomId);

  if (room) {
    try {
      const filePath = path.join(process.cwd(), "public", room.imageFile);
      const bytes = await readFile(filePath);
      const form = new FormData();
      form.set("caption", caption);
      form.set("parse_mode", "HTML");
      if (markup) form.set("reply_markup", JSON.stringify(markup));
      form.set("photo", new Blob([new Uint8Array(bytes)], { type: "image/jpeg" }), `${room.id}.jpg`);
      return await telegramRequest("sendPhoto", form);
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("не настроен") || message.includes("Unauthorized") || message.includes("chat not found")) {
        throw error;
      }
    }
  }

  return telegramRequest("sendMessage", {
    text: caption,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    reply_markup: markup,
  });
}
